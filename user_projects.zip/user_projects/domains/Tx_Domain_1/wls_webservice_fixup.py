# Deprecated. Please use wls_webservice_complete_update.py instead.
# Created By WLS Advanced Web Services Template Version 10.3.3.0

import wls_webservice_fixup_utils as fixup

domainDir = sys.argv[1]
print "Will verify/correct WSEE configuration in domain dir: %s" % (domainDir)

readDomain(domainDir)

# Perform any WLS fixup we need assuming that our JMS module has been assigned
# to the desired targets already

wseeServerNames = fixup.doWseeFixup(globals())

# Save changes
updateDomain()

print "Done with WSEE configuration. Configured these servers: %s" % (wseeServerNames)

exit()
